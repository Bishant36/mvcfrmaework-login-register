<?php 

class userController extends framework{

    public function index(){
        $this->view('userView');
    }

    public function userMethod(){

        $myModel = $this->model('userModel');
        if($myModel->mydata()){
          $result= $myModel->myData();
    }else{
        echo " not register";
    }
    $this->view("userView", $result);
    }
    
}





?>