<?php
class userModel extends database{

    public function myData(){
        $id= "2";
        $name= "Bishant Bhattarai";
        $email= "bishant@gmail.com";
        $password= "12345678";
        if($this->query("SELECT * FROM users")){
            return $this->fetchall();
        }else{
            return false;
        }
        

        
        }
} 






?>