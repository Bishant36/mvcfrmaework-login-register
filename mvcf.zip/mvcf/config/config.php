<?php

define("HOST", "localhost");
define("USER", "root");
define("DATABASE", "mvc");
define("PASSWORD", "");










?>